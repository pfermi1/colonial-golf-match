const els = {
  setupCard: document.querySelector('#setupCard'),
  reviewCard: document.querySelector('#reviewCard'),
  confirmedCard: document.querySelector('#confirmedCard'),
  teamName: document.querySelector('#teamName'),
  playerCount: document.querySelector('#playerCount'),
  file: document.querySelector('#scorecardFile'),
  photoArea: document.querySelector('#photoArea'),
  preview: document.querySelector('#photoPreview'),
  changePhoto: document.querySelector('#changePhoto'),
  status: document.querySelector('#status'),
  readButton: document.querySelector('#readButton'),
  reviewTitle: document.querySelector('#reviewTitle'),
  playersReview: document.querySelector('#playersReview'),
  warnings: document.querySelector('#warnings'),
  backButton: document.querySelector('#backButton'),
  confirmButton: document.querySelector('#confirmButton'),
  showPhoto: document.querySelector('#showPhoto'),
  photoDialog: document.querySelector('#photoDialog'),
  dialogImage: document.querySelector('#dialogImage'),
  closeDialog: document.querySelector('#closeDialog'),
  confirmedTitle: document.querySelector('#confirmedTitle'),
  confirmedSummary: document.querySelector('#confirmedSummary'),
  editConfirmed: document.querySelector('#editConfirmed'),
  newCard: document.querySelector('#newCard')
};

const state = {
  imageDataUrl: '',
  players: [],
  warnings: [],
  confirmed: false
};

els.file.addEventListener('change', handleFile);
els.changePhoto.addEventListener('click', () => els.file.click());
els.readButton.addEventListener('click', readScorecard);
els.backButton.addEventListener('click', () => showScreen('setup'));
els.confirmButton.addEventListener('click', confirmScorecard);
els.showPhoto.addEventListener('click', openPhoto);
els.closeDialog.addEventListener('click', () => els.photoDialog.close());
els.editConfirmed.addEventListener('click', () => showScreen('review'));
els.newCard.addEventListener('click', resetApp);

async function handleFile(event) {
  const file = event.target.files?.[0];
  if (!file) return;
  setStatus('Preparing photo…');
  try {
    state.imageDataUrl = await resizeImage(file, 1800, 0.86);
    els.preview.src = state.imageDataUrl;
    els.dialogImage.src = state.imageDataUrl;
    els.photoArea.classList.remove('hidden');
    els.readButton.disabled = false;
    hideStatus();
  } catch (error) {
    setStatus(`Could not prepare the photo: ${error.message}`, 'error');
  }
}

async function resizeImage(file, maxDimension, quality) {
  const dataUrl = await fileToDataUrl(file);
  const image = await loadImage(dataUrl);
  const scale = Math.min(1, maxDimension / Math.max(image.width, image.height));
  const canvas = document.createElement('canvas');
  canvas.width = Math.round(image.width * scale);
  canvas.height = Math.round(image.height * scale);
  const ctx = canvas.getContext('2d');
  ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL('image/jpeg', quality);
}

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error('The image could not be read.'));
    reader.readAsDataURL(file);
  });
}

function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('The browser could not open this image format. Try a JPG screenshot.'));
    img.src = src;
  });
}

async function readScorecard() {
  if (!state.imageDataUrl) return;
  const requestedPlayers = Number(els.playerCount.value);
  els.readButton.disabled = true;
  setStatus('Reading names and scores… This may take 10–30 seconds.');

  try {
    const response = await fetch('/.netlify/functions/read-scorecard', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ imageDataUrl: state.imageDataUrl, requestedPlayers })
    });

    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || `Reader failed (${response.status}).`);

    state.players = normalizePlayers(payload.players, requestedPlayers);
    state.warnings = Array.isArray(payload.warnings) ? payload.warnings : [];
    renderReview();
    hideStatus();
    showScreen('review');
  } catch (error) {
    setStatus(`${error.message} You can try a closer, straighter picture.`, 'error');
  } finally {
    els.readButton.disabled = false;
  }
}

function normalizePlayers(players, requestedPlayers) {
  const list = Array.isArray(players) ? players.slice(0, requestedPlayers) : [];
  while (list.length < requestedPlayers) list.push({ name: `Player ${list.length + 1}`, scores: [] });
  return list.map((player, index) => ({
    name: String(player?.name || `Player ${index + 1}`).trim(),
    scores: Array.from({ length: 18 }, (_, hole) => {
      const raw = player?.scores?.[hole];
      const value = Number(raw?.value ?? raw);
      return {
        value: Number.isInteger(value) && value >= 1 && value <= 20 ? value : '',
        uncertain: Boolean(raw?.uncertain) || !(Number.isInteger(value) && value >= 1 && value <= 20)
      };
    })
  }));
}

function renderReview() {
  const team = cleanTeamName();
  els.reviewTitle.textContent = team;
  els.playersReview.innerHTML = '';

  const warningItems = [...state.warnings];
  state.players.forEach((p, pi) => p.scores.forEach((s, hi) => {
    if (s.uncertain) warningItems.push(`${p.name}: check score ${hi + 1}`);
  }));

  if (warningItems.length) {
    els.warnings.classList.remove('hidden');
    els.warnings.innerHTML = `<strong>Please double-check:</strong><ul>${warningItems.map(w => `<li>${escapeHtml(w)}</li>`).join('')}</ul>`;
  } else {
    els.warnings.classList.add('hidden');
    els.warnings.innerHTML = '';
  }

  state.players.forEach((player, playerIndex) => {
    const card = document.createElement('article');
    card.className = 'player-card';

    const name = document.createElement('input');
    name.className = 'player-name';
    name.value = player.name;
    name.setAttribute('aria-label', `Player ${playerIndex + 1} name`);
    name.addEventListener('input', () => { player.name = name.value; });
    card.appendChild(name);

    [0, 9].forEach(start => {
      const row = document.createElement('div');
      row.className = 'score-row';
      for (let offset = 0; offset < 9; offset++) {
        const holeIndex = start + offset;
        const score = player.scores[holeIndex];
        const input = document.createElement('input');
        input.type = 'number';
        input.inputMode = 'numeric';
        input.min = '1';
        input.max = '20';
        input.value = score.value;
        input.className = `score-input${score.uncertain ? ' uncertain' : ''}`;
        input.setAttribute('aria-label', `${player.name} hole ${holeIndex + 1}`);
        input.addEventListener('input', () => {
          const value = Number(input.value);
          score.value = Number.isInteger(value) && value >= 1 && value <= 20 ? value : '';
          score.uncertain = score.value === '';
          input.classList.toggle('uncertain', score.uncertain);
          updateTotals(card, player);
        });
        row.appendChild(input);
      }
      const total = document.createElement('div');
      total.className = `row-total ${start === 0 ? 'front-total' : 'back-total'}`;
      row.appendChild(total);
      card.appendChild(row);
    });

    const grand = document.createElement('div');
    grand.className = 'grand-total';
    grand.innerHTML = '<span>Total</span><strong class="total-value">—</strong>';
    card.appendChild(grand);
    els.playersReview.appendChild(card);
    updateTotals(card, player);
  });
}

function updateTotals(card, player) {
  const values = player.scores.map(s => Number(s.value));
  const valid = values.every(v => Number.isInteger(v) && v >= 1);
  const frontValid = values.slice(0, 9).every(Number.isInteger);
  const backValid = values.slice(9).every(Number.isInteger);
  card.querySelector('.front-total').textContent = frontValid ? sum(values.slice(0, 9)) : '—';
  card.querySelector('.back-total').textContent = backValid ? sum(values.slice(9)) : '—';
  card.querySelector('.total-value').textContent = valid ? sum(values) : '—';
}

function confirmScorecard() {
  const invalid = state.players.some(p => !p.name.trim() || p.scores.some(s => !Number.isInteger(Number(s.value))));
  if (invalid) {
    alert('Please fill in every player name and all 18 scores before confirming.');
    return;
  }

  const record = {
    teamName: cleanTeamName(),
    confirmedAt: new Date().toISOString(),
    players: state.players.map(p => ({ name: p.name.trim(), scores: p.scores.map(s => Number(s.value)) }))
  };
  localStorage.setItem('colonialGolfMatch:lastConfirmedCard', JSON.stringify(record));
  state.confirmed = true;
  renderConfirmed(record);
  showScreen('confirmed');
}

function renderConfirmed(record) {
  els.confirmedTitle.textContent = `${record.teamName} Scorecard Saved`;
  els.confirmedSummary.innerHTML = record.players.map(player => {
    const front = sum(player.scores.slice(0, 9));
    const back = sum(player.scores.slice(9));
    return `<div class="summary-player"><span>${escapeHtml(player.name)}</span><strong>${front}</strong><strong>${back}</strong><strong>${front + back}</strong></div>`;
  }).join('');
}

function showScreen(screen) {
  els.setupCard.classList.toggle('hidden', screen !== 'setup');
  els.reviewCard.classList.toggle('hidden', screen !== 'review');
  els.confirmedCard.classList.toggle('hidden', screen !== 'confirmed');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function openPhoto() {
  if (!state.imageDataUrl) return;
  if (typeof els.photoDialog.showModal === 'function') els.photoDialog.showModal();
  else window.open(state.imageDataUrl, '_blank');
}

function resetApp() {
  state.imageDataUrl = '';
  state.players = [];
  state.warnings = [];
  state.confirmed = false;
  els.file.value = '';
  els.preview.removeAttribute('src');
  els.photoArea.classList.add('hidden');
  els.readButton.disabled = true;
  hideStatus();
  showScreen('setup');
}

function cleanTeamName() {
  const raw = els.teamName.value.trim().replace(/^team\s+/i, '');
  return `Team ${raw || 'Unnamed'}`;
}

function setStatus(message, type = '') {
  els.status.textContent = message;
  els.status.className = `status${type ? ` ${type}` : ''}`;
}

function hideStatus() {
  els.status.className = 'status hidden';
  els.status.textContent = '';
}

function sum(values) { return values.reduce((total, value) => total + Number(value || 0), 0); }
function escapeHtml(value) { return String(value).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }
