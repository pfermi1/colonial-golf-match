export default async (request) => {
  if (request.method !== 'POST') {
    return json({ error: 'Method not allowed.' }, 405);
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return json({ error: 'OPENAI_API_KEY is missing from Netlify environment variables.' }, 500);
  }

  try {
    const body = await request.json();
    const imageDataUrl = body?.imageDataUrl;
    const requestedPlayers = Number(body?.requestedPlayers || 4);

    if (typeof imageDataUrl !== 'string' || !imageDataUrl.startsWith('data:image/')) {
      return json({ error: 'A valid scorecard image is required.' }, 400);
    }
    if (![4, 5].includes(requestedPlayers)) {
      return json({ error: 'Player count must be 4 or 5.' }, 400);
    }

    const schema = {
      type: 'object',
      additionalProperties: false,
      properties: {
        players: {
          type: 'array',
          minItems: requestedPlayers,
          maxItems: requestedPlayers,
          items: {
            type: 'object',
            additionalProperties: false,
            properties: {
              name: { type: 'string' },
              scores: {
                type: 'array',
                minItems: 18,
                maxItems: 18,
                items: {
                  type: 'object',
                  additionalProperties: false,
                  properties: {
                    value: { anyOf: [{ type: 'integer', minimum: 1, maximum: 20 }, { type: 'null' }] },
                    uncertain: { type: 'boolean' }
                  },
                  required: ['value', 'uncertain']
                }
              }
            },
            required: ['name', 'scores']
          }
        },
        warnings: { type: 'array', items: { type: 'string' } }
      },
      required: ['players', 'warnings']
    };

    const prompt = `You are reading a photographed Colonial Golf Course paper scorecard.
Extract exactly ${requestedPlayers} handwritten player rows, in top-to-bottom order.
For each player, return the handwritten name and exactly 18 hole scores (holes 1 through 18).
Ignore all printed yardages, pars, handicaps, tee information, totals printed on the card, signatures, notes, and any handwritten 1-ball, 2-ball, 2+3-ball, bet, or summary rows below the player rows.
Do not use handwritten front-nine, back-nine, or total figures as hole scores.
Each ordinary golf hole score should normally be 1 through 12. If a digit is unclear, return null and uncertain=true rather than guessing.
If a name is unclear, give your best short transcription and add a warning.
Return only data matching the provided JSON schema.`;

    const openAIResponse = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gpt-4.1-mini',
        input: [{
          role: 'user',
          content: [
            { type: 'input_text', text: prompt },
            { type: 'input_image', image_url: imageDataUrl, detail: 'high' }
          ]
        }],
        text: {
          format: {
            type: 'json_schema',
            name: 'colonial_scorecard',
            strict: true,
            schema
          }
        },
        max_output_tokens: 3500
      })
    });

    const raw = await openAIResponse.json();
    if (!openAIResponse.ok) {
      const message = raw?.error?.message || 'OpenAI could not read the scorecard.';
      return json({ error: message }, openAIResponse.status);
    }

    const outputText = getOutputText(raw);
    if (!outputText) return json({ error: 'The reader returned no structured score data.' }, 502);

    let parsed;
    try {
      parsed = JSON.parse(outputText);
    } catch {
      return json({ error: 'The scorecard response could not be parsed.' }, 502);
    }

    return json(parsed, 200);
  } catch (error) {
    return json({ error: error?.message || 'Unexpected scorecard reader error.' }, 500);
  }
};

function getOutputText(response) {
  if (typeof response?.output_text === 'string') return response.output_text;
  for (const item of response?.output || []) {
    for (const content of item?.content || []) {
      if (content?.type === 'output_text' && typeof content?.text === 'string') return content.text;
    }
  }
  return '';
}

function json(payload, status) {
  return new Response(JSON.stringify(payload), {
    status,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }
  });
}
