# Colonial Golf Match v0.1

The first working foundation for an AI-assisted Colonial Golf scorecard reader.

## What this version does

- Takes or uploads a scorecard photo
- Sends the image securely through a Netlify Function
- Uses the OpenAI API to read 4 or 5 player names and 18 scores per player
- Flags uncertain scores
- Provides a simple mobile review/correction screen
- Calculates each player's front nine, back nine, and total
- Saves the last confirmed card on the current device

## Not in v0.1 yet

- Shared database
- Multiple team scorecards in one saved game
- 1 Ball / 2 Ball
- 1 Ball / 2+3 Ball
- Stableford, quota, skins, or Nassau
- Automatic presses and settlement calculations

These will be added after the scorecard reader is tested with real Colonial cards.

## Netlify setup

1. In Netlify, create the environment variable `OPENAI_API_KEY`.
2. Make sure its scope includes **Functions**.
3. Link this GitHub repository to the existing Netlify project.
4. Build command: leave blank.
5. Publish directory: `.`
6. Deploy.

Environment variable changes require a new deploy before Netlify Functions see the new value.

## Uploading this first version to an empty GitHub repository

On the empty repository page, choose **uploading an existing file**. Upload the contents of this project folder, including the `netlify` folder, and commit them to the `main` branch.

GitHub's browser upload may not preserve an empty folder, but this project has a real file inside `netlify/functions`, so the folder will be included.

## Security

Never place the OpenAI API key in `index.html`, `app.js`, GitHub, or chat. It belongs only in Netlify environment variables.
